
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

var cont = 1;



var ctx = document.getElementById("myAreaChart");

var myLineChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: "Temperatura",
        lineTension: 0.3,
        backgroundColor: "rgba(78, 115, 223, 0.05)",
        borderColor: "rgba(78, 115, 223, 1)",
        pointRadius: 3,
        pointBackgroundColor: "rgba(78, 115, 223, 1)",
        pointBorderColor: "rgba(78, 115, 223, 1)",
        pointHoverRadius: 3,
        pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
        pointHoverBorderColor: "rgba(78, 115, 223, 1)",
        pointHitRadius: 10,
        pointBorderWidth: 2,
        data: [],
      }],
    }

});

function addData(chart, label, data){
    chart.data.labels.push(label);
    chart.data.datasets.forEach((dataset)=> {
        dataset.data.push(data);
    });
    chart.update();
}

//document.getElementById("boton_canvas").addEventListener("click", function(event){}, false);
document.getElementById("boton_canvas").addEventListener("click", function(event){
    
    $.get({
      url: '/data_graph',
      contentType: 'application/json',
      success: function(res, status){
        addData(myLineChart, cont, res.TEMP+cont);
        //alert(res.TEMP);
      }
    });

    cont++;

    //

}, false);

document.getElementById("btn_luces").addEventListener("click", function(event){

  var json = {
    "L1":document.getElementById("L1").checked,
    "L2":document.getElementById("L2").checked,
    "L3":document.getElementById("L3").checked,
    "L4":document.getElementById("L4").checked
  }

  /*
  var json = {
    "L1":"OK",
    "L2":"OK",
    "L3":"OK",
    "L4":"OK"
  }
*/
  $.post({
    url: '/data_luces',
    contentType: 'application/json',
    data: JSON.stringify(json),
    success: function(res, status){
     // alert(res.body);
      //alert(res.TEMP);
    }
  });

  //

}, false);




