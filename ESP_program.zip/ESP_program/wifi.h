#ifndef _WIFI_H_
#define _WIFI_H_

#include "include.h"
#include <WiFi.h>   // <> librerias de arduino
#include <HTTPClient.h>

class ESP_WIFI{

  public:
    const int port=3000;
    bool init(); //metodos de iniciacion en booleano
    void server_esp(); 
    void Process_request(int value);
    void get_req(String path);
    
  private:

    void post_req(String path,String Value);
    void interpretar_json(String json,bool led_state[],int size);
    void split(String inputString, char delimiter, String outputArray[], int outputSize);
    void palabra_dentro(bool led_state[],String contenido[],int size);
    void encender(int leds[],bool state_leds[]);
    const char* ssid ="Arthur";
    const char* pass ="12345678";
    uint32_t last_T;
    #define TIME_OUT 20000 // valor estatico, con #define se optimiza memoria
    int currentTime;
    int previousTime;
    String header;

    const String server="http://192.168.197.17";
    const String ID="ESP_01";
    String url;
    int gpio_led[4] = {LedA,LedB,LedC,LedD};


};



#endif
