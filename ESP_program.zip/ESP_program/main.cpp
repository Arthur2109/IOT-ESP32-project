#include "main.h"

Ser S;
ESP_WIFI W;

void FSM::FSM_Principal(int estado_1){
  if(estado_1 == inicio){

   // S.init();
    Serial.begin(9600);
    W.init();
    
    estado = opera;
  }else if(estado_1 == conf){


    
  }else if(estado_1 == opera){
    //S.leerserial();
    //W.server_esp();
    delay(500);
    //W.Process_request(cont);
    //Serial.println("petición mandada");
    Serial.println("tout va bien");
    W.get_req("data_luces_ESP");
    //cont++;
    

  }
}

void FSM::Init(){

  
}

int FSM::get_state(){

  return estado;
  
}
