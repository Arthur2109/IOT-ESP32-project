#ifndef _INCLUDE_H_
#define _INCLUDE_H_

#include <Arduino.h>
#include <HardwareSerial.h>

#include <WiFi.h>
#define LR 16
#define LV 17
#define LedA 18
#define LedB 19
#define LedC 21
#define LedD 17












#endif
