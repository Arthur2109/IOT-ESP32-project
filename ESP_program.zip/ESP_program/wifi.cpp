#include "wifi.h"

WiFiClient client;
WiFiServer server(3000); //servidor(puerto)

bool ESP_WIFI::init(){

  last_T =millis();
  WiFi.begin(ssid, pass);
  Serial.println("Connecting...");
  while(WiFi.status() != WL_CONNECTED){
    if(millis() - last_T > TIME_OUT){
      Serial.println("Connection timed out");
      digitalWrite(LV, LOW);
      digitalWrite(LR, HIGH);
      delay(500);
      return false;
    }else{
    Serial.println(".");
    delay(500);
    }
  }
  Serial.println("Conectado a");
  Serial.print (ssid);
  Serial.println("Direccion IP");
  Serial.println(WiFi.localIP());
  header = "";
  server.begin();
  digitalWrite(LV, HIGH);
  digitalWrite(LR, LOW);
  delay(500);
  return true;
}


/*
void ESP_WIFI::server_esp(){
  WiFiClient client = server.available();
  client = server.available();
  if(client){
    currentTime = millis();
    previousTime = currentTime;
    Serial.println("Nuevo Cliente");
    String currentLine = "";
    while(client.connected() && currentTime-previousTime<=TIME_OUT){
      currentTime = millis();
      if(client.available()){
        char c = client.read();
        Serial.write(c);
        header += c;
        if(c == '\n'){
          if(currentLine.length() == 0){
            client.println("HTTP/1.1 200 OK"); //HTTP versio 1.1 codigo 200 (Peticion esta OK)
            client.println("Content-type:text/html"); //tipo de contenido: texto en html
            client.println("Connection: close");
            client.println();
            if(header.indexOf("GET /LED_ON") >= 0){ //get mando y responde, post envia
              Serial.println("LED ON");
              
            }else if(header.indexOf("GET /LED_OFF") >= 0){ //get mando y responde, post envia
              Serial.println("LED OFF");
            }

            //espacio para enviar pagina web
            break;
          }else{
            currentLine = "";
              
          }
        }else if(c != '\r'){
          currentLine += c;
        }
      }
    Serial.println("test");
    }
    header = "";
    client.stop();
    Serial.println("Cliente desconectado");
  }
}
*/


void ESP_WIFI::post_req(String path, String Value){
  HTTPClient http;
  String url =  server + ":"+ "3000" + path;
  Serial.println(url);
  bool stat= http.begin(client, url);
  if (stat){
    //agregamos headers
    http.addHeader("Content-Type","application/json");
    // enviamos la petición post
    int httpcode=http.POST(Value);
    if (httpcode==200){
      Serial.print("post exitoso");
    }
    else{
      Serial.print("error en comunicación");
    }
  }
  
  else{
    Serial.println("No se encontró ruta");
  }
  http.end();
    
}

void ESP_WIFI::Process_request(int value){
  String json = "{\"ID\" : \"" + ID + "\", \"TEMP\":" + String(value) + "}";

  //realizamos la petición
  post_req("/data_esp",json);
}


void ESP_WIFI::get_req(String path){
  HTTPClient http;
  url =  server + ":"+ port +"/"+ path; // c'est une variable privée elle ne peut donc pas etre utilisée dans main.cpp par exemple
  Serial.println(url);
  if (http.begin(client,url)){ // Verfificamos la conexion
    //agregamos los headers
    http.addHeader("Content-Type","application/json");
    //Realizamos la peticion
    int httpcode=http.GET();
    //Serial.println(httpcode);
    String payload=http.getString();
  //  Serial.println(httpcode);
     // on check si payload est vide

    int size=4;
    bool estado_led[4];
    
    interpretar_json(payload,estado_led,size);
    encender(gpio_led, estado_led);


  }else {
    Serial.println("No Hay conexión");
  }
  http.end();
}


void ESP_WIFI::interpretar_json(String json,bool led_state[],int size){
  
  char delimitador=',';
  String contenido[size];
  Serial.println(json);
  split(json,delimitador,contenido,size); // on remplit contenido
  palabra_dentro(led_state,contenido,size);  // on actualise contenido avec des valeurs booleennes
}

void ESP_WIFI::split(String inputString, char delimiter, String outputArray[], int outputSize) {
  int i = 0;
  int lastDelimiterIndex = 0;
  int outputIndex = 0;
  while (i < inputString.length() && outputIndex < outputSize) {
    if (inputString.charAt(i) == delimiter) {
      outputArray[outputIndex] = inputString.substring(lastDelimiterIndex, i);
      lastDelimiterIndex = i + 1;
      outputIndex++;
    }
    i++;
  }
  if (lastDelimiterIndex < inputString.length() && outputIndex < outputSize) {
    outputArray[outputIndex] = inputString.substring(lastDelimiterIndex);
    outputIndex++;
  }
  while (outputIndex < outputSize) {
    outputArray[outputIndex] = "";
    outputIndex++;
  }
}

void ESP_WIFI::palabra_dentro(bool led_state[],String contenido[],int size) {

  for (int i=0;i<size;i++){
    int posicion = contenido[i].indexOf("true");
    if (posicion<0){led_state[i]=0;}
    else{led_state[i]=1;}
  }
}

void ESP_WIFI::encender(int leds[], bool state_leds[]){
  for (int i=0; i<4; i++){
    digitalWrite(leds[i], state_leds[i]);
    Serial.print("estado led ");
    Serial.print(leds[i]);
    Serial.print(": ");
    Serial.println(state_leds[i]);
  }
}
